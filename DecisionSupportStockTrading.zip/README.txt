A Cell-DEVS implementation of a Decision Support System for Stock Market Trading
Author: Guillermo Trabes

The times for the simulations is too short for a video, all the results obtained are in the inform DecisionSupportStockTrading.doc


/***************************************************************/

To execute the experiment 1 the following files are needed

exp1-Stock-EXE.exe: executable file
exp1-Stock-MA.ma: coupled model file
exp1-Stock-PAL.pal: palette value
exp1-Stock-VAL.val: initial configuration value

The result will be saved on the file
exp1-Stock-LOG.log


/***************************************************************/

To execute the experiment 2 the following files are needed

exp2-Stock-EXE.exe: executable file
exp2-Stock-MA.ma: coupled model file
exp2-Stock-PAL.pal: palette value
exp2-Stock-VAL.val: initial configuration value

The result will be saved on the file
exp2-Stock-LOG.log

/***************************************************************/

To execute the experiment 3 the following files are needed

exp3-Stock-EXE.exe: executable file
exp3-Stock-MA.ma: coupled model file
exp3-Stock-PAL.pal: palette value
exp3-Stock-VAL.val: initial configuration value

The result will be saved on the file
exp3-Stock-LOG.log

/***************************************************************/

To execute the experiment 4 the following files are needed

exp4-Stock-EXE.exe: executable file
exp4-Stock-MA.ma: coupled model file
exp4-Stock-PAL.pal: palette value
exp4-Stock-VAL.val: initial configuration value

The result will be saved on the file
exp4-Stock-LOG.log

/***************************************************************/

To execute the experiment 5 the following files are needed

exp5-Stock-EXE.exe: executable file
exp5-Stock-MA.ma: coupled model file
exp5-Stock-PAL.pal: palette value
exp5-Stock-VAL.val: initial configuration value

The result will be saved on the file
exp5-Stock-LOG.log